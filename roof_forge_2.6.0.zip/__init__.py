bl_info = {
    "name": "RoofForge - Parametric Roof Generator",
    "author": "OpenAI",
    "version": (2, 6, 0),
    "blender": (5, 0, 0),
    "location": "View3D > Sidebar > RoofForge",
    "description": "Low-poly roofs and automatic lightweight standing-seam layout",
    "category": "Add Mesh",
}

import bpy
import bmesh
import json
import math
from collections import defaultdict
from mathutils import Vector
from bpy.props import (
    EnumProperty,
    FloatProperty,
    BoolProperty,
    PointerProperty,
)

from .straight_skeleton_2_6_0 import (
    SkeletonError,
    build_roof_mesh,
    _orthogonalize_nearly_orthogonal_contour,
    extend_roof_mesh_eaves,
    extract_roof_seams,
    build_inset_seam_profile_mesh,
)
from .standing_seams_2_6_0 import build_standing_seam_mesh


# -----------------------------------------------------------------------------
# Geometry core (pure Python; no external packages required)
# -----------------------------------------------------------------------------

_EPS = 1.0e-9


class RoofForgeError(Exception):
    pass


def _add(a, b):
    return (a[0] + b[0], a[1] + b[1])


def _sub(a, b):
    return (a[0] - b[0], a[1] - b[1])


def _mul(a, s):
    return (a[0] * s, a[1] * s)


def _dot(a, b):
    return a[0] * b[0] + a[1] * b[1]


def _cross(a, b):
    return a[0] * b[1] - a[1] * b[0]


def _length(a):
    return math.hypot(a[0], a[1])


def _normalize(a):
    length = _length(a)
    if length < _EPS:
        raise RoofForgeError("В контуре есть ребро нулевой длины.")
    return (a[0] / length, a[1] / length)


def _signed_area(poly):
    return 0.5 * sum(_cross(poly[i], poly[(i + 1) % len(poly)]) for i in range(len(poly)))


def _orientation(a, b, c):
    return _cross(_sub(b, a), _sub(c, a))


def _on_segment(a, b, p, eps):
    return (
        min(a[0], b[0]) - eps <= p[0] <= max(a[0], b[0]) + eps
        and min(a[1], b[1]) - eps <= p[1] <= max(a[1], b[1]) + eps
    )


def _segments_intersect(a, b, c, d, eps):
    o1 = _orientation(a, b, c)
    o2 = _orientation(a, b, d)
    o3 = _orientation(c, d, a)
    o4 = _orientation(c, d, b)
    if ((o1 > eps and o2 < -eps) or (o1 < -eps and o2 > eps)) and \
       ((o3 > eps and o4 < -eps) or (o3 < -eps and o4 > eps)):
        return True
    if abs(o1) <= eps and _on_segment(a, b, c, eps):
        return True
    if abs(o2) <= eps and _on_segment(a, b, d, eps):
        return True
    if abs(o3) <= eps and _on_segment(c, d, a, eps):
        return True
    if abs(o4) <= eps and _on_segment(c, d, b, eps):
        return True
    return False


def _validate_simple_polygon(poly, eps):
    count = len(poly)
    for i in range(count):
        a, b = poly[i], poly[(i + 1) % count]
        for j in range(i + 1, count):
            if j == i or j == (i + 1) % count or (j + 1) % count == i:
                continue
            c, d = poly[j], poly[(j + 1) % count]
            if _segments_intersect(a, b, c, d, eps):
                raise RoofForgeError("Контур самопересекается или касается сам себя. Исправьте порядок рёбер.")


def _simplify_polygon(poly, scale):
    eps = max(1.0e-8, scale * 1.0e-8)
    cleaned = []
    for point in poly:
        if not cleaned or _length(_sub(point, cleaned[-1])) > eps:
            cleaned.append((float(point[0]), float(point[1])))
    if len(cleaned) > 2 and _length(_sub(cleaned[0], cleaned[-1])) <= eps:
        cleaned.pop()

    changed = True
    while changed and len(cleaned) >= 3:
        changed = False
        result = []
        n = len(cleaned)
        for i in range(n):
            prev = cleaned[(i - 1) % n]
            curr = cleaned[i]
            nxt = cleaned[(i + 1) % n]
            a = _sub(curr, prev)
            b = _sub(nxt, curr)
            if abs(_cross(a, b)) <= eps * max(_length(a), _length(b), 1.0) and _dot(a, b) >= -eps:
                changed = True
                continue
            result.append(curr)
        cleaned = result

    if len(cleaned) < 3:
        raise RoofForgeError("В контуре должно быть не менее трёх разных углов.")
    area = _signed_area(cleaned)
    if abs(area) <= eps * eps:
        raise RoofForgeError("Площадь контура слишком мала или контур вырожден.")
    if area < 0.0:
        cleaned.reverse()
    _validate_simple_polygon(cleaned, eps)
    return cleaned


def _line_intersection(p, direction_a, q, direction_b):
    den = _cross(direction_a, direction_b)
    if abs(den) < 1.0e-10:
        return None
    t = _cross(_sub(q, p), direction_b) / den
    return _add(p, _mul(direction_a, t))


def _offset_polygon(poly, distance):
    """Miter offset for simple concave or convex polygons; rejects collapsed/self-crossing offsets."""
    if distance <= 1.0e-10:
        return list(poly)
    shifted = []
    for i, p in enumerate(poly):
        q = poly[(i + 1) % len(poly)]
        edge = _normalize(_sub(q, p))
        outward = (edge[1], -edge[0])  # polygon is CCW
        shifted.append((_add(p, _mul(outward, distance)), edge))

    result = []
    for i in range(len(poly)):
        prev_p, prev_dir = shifted[i - 1]
        curr_p, curr_dir = shifted[i]
        hit = _line_intersection(prev_p, prev_dir, curr_p, curr_dir)
        if hit is None:
            raise RoofForgeError("Не удалось построить свес: есть почти параллельные соседние рёбра.")
        result.append(hit)

    scale = max(max(_length(_sub(result[(i + 1) % len(result)], result[i])) for i in range(len(result))), 1.0)
    result = _simplify_polygon(result, scale)
    if _signed_area(result) <= 1.0e-8:
        raise RoofForgeError("Свес слишком велик: контур крыши схлопнулся.")
    return result


def _is_parallelogram(poly, tolerance=1.0e-4):
    if len(poly) != 4:
        return False
    e = [_sub(poly[(i + 1) % 4], poly[i]) for i in range(4)]
    scale = max(max(_length(v) for v in e), 1.0)
    return abs(_cross(e[0], e[2])) <= tolerance * scale * scale and \
           abs(_cross(e[1], e[3])) <= tolerance * scale * scale


def _create_surface_geometry(poly, settings, eave_lift_override=None):
    """Build the roof as exact planar faces; never sample or subdivide its surface.

    HIP is built by the straight-skeleton wavefront event graph. Every original
    contour edge creates a single planar roof facet (or multiple components
    only when that edge's facet is topologically split by a valid event).
    """
    roof_type = settings.roof_type
    pitch = settings.pitch_angle
    lift = settings.eave_lift if eave_lift_override is None else float(eave_lift_override)

    if roof_type in {'HIP', 'HIP_FREE'}:
        return build_roof_mesh(
            poly, math.tan(pitch), lift, allow_oblique=(roof_type == 'HIP_FREE')
        )

    if roof_type == 'FLAT':
        roof_vertices = [(p[0], p[1], lift) for p in poly]
        return roof_vertices, [tuple(range(len(poly)))], [-1]

    tan_pitch = math.tan(pitch)

    if roof_type == 'SHED':
        angle = settings.shed_rise_angle
        direction = (math.cos(angle), math.sin(angle))
        projections = [_dot(p, direction) for p in poly]
        low = min(projections)
        roof_vertices = [
            (p[0], p[1], (projection - low) * tan_pitch + lift)
            for p, projection in zip(poly, projections)
        ]
        return roof_vertices, [tuple(range(len(poly)))], [-1]

    if roof_type == 'GABLE':
        if not _is_parallelogram(poly):
            raise RoofForgeError(
                "Двускатный режим требует четырёхугольник-параллелограмм. "
                "Для сложного контура используйте вальмовый режим."
            )
        edges = [_sub(poly[(i + 1) % 4], poly[i]) for i in range(4)]
        lengths = [_length(e) for e in edges]
        long_edge = 0 if lengths[0] + lengths[2] >= lengths[1] + lengths[3] else 1
        a = long_edge
        b = (a + 1) % 4
        c = (a + 2) % 4
        d = (a + 3) % 4
        edge_dir = _normalize(edges[a])
        inward_normal = (-edge_dir[1], edge_dir[0])
        line_a = _dot(inward_normal, poly[a])
        line_b = _dot(inward_normal, poly[c])
        ridge_a = _mul(_add(poly[d], poly[a]), 0.5)
        ridge_b = _mul(_add(poly[b], poly[c]), 0.5)
        ridge_height = abs(line_b - line_a) * 0.5 * tan_pitch + lift

        roof_vertices = [(p[0], p[1], lift) for p in poly]
        ridge_a_id = len(roof_vertices)
        roof_vertices.append((ridge_a[0], ridge_a[1], ridge_height))
        ridge_b_id = len(roof_vertices)
        roof_vertices.append((ridge_b[0], ridge_b[1], ridge_height))
        faces = [
            (a, b, ridge_b_id, ridge_a_id),
            (ridge_a_id, ridge_b_id, c, d),
        ]
        # Shared ridge is extracted from the two actual roof-face boundaries.
        # Keep every projected face loop counter-clockwise (upward-facing).
        oriented_faces = []
        for face in faces:
            pts = [roof_vertices[i] for i in face]
            twice_area = sum(
                p[0] * pts[(i + 1) % len(pts)][1]
                - pts[(i + 1) % len(pts)][0] * p[1]
                for i, p in enumerate(pts)
            )
            oriented_faces.append(tuple(reversed(face)) if twice_area < 0.0 else tuple(face))
        return roof_vertices, oriented_faces, [-1, -2]

    raise RoofForgeError("Неизвестный тип крыши.")


# -----------------------------------------------------------------------------
# Input loop extraction
# -----------------------------------------------------------------------------


def _order_single_loop(vertex_coordinates, edge_pairs):
    adjacency = defaultdict(list)
    for a, b in edge_pairs:
        if a == b:
            continue
        adjacency[a].append(b)
        adjacency[b].append(a)
    if len(adjacency) < 3:
        raise RoofForgeError("Не найден замкнутый контур минимум из трёх вершин.")
    bad = [vid for vid, neighbours in adjacency.items() if len(neighbours) != 2]
    if bad:
        raise RoofForgeError("Выбранные рёбра должны образовывать один замкнутый loop без ответвлений и разрывов.")
    start = next(iter(adjacency))
    ordered = [start]
    previous = None
    current = start
    for _ in range(len(adjacency) + 1):
        neighbours = adjacency[current]
        nxt = neighbours[0] if neighbours[0] != previous else neighbours[1]
        if nxt == start:
            break
        if nxt in ordered:
            raise RoofForgeError("В выделении найдено больше одного контура или самопересечение.")
        ordered.append(nxt)
        previous, current = current, nxt
    if len(ordered) != len(adjacency):
        raise RoofForgeError("Выделение содержит несколько отдельных контуров. Оставьте один замкнутый loop.")
    try:
        return [vertex_coordinates[index] for index in ordered]
    except KeyError as exc:
        raise RoofForgeError("Не удалось прочитать координаты всех вершин контура.") from exc


def _extract_loop_from_object(obj):
    if obj is None or obj.type != 'MESH':
        raise RoofForgeError("Активным объектом должен быть Mesh с контуром карниза.")
    if obj.mode == 'EDIT':
        bm = bmesh.from_edit_mesh(obj.data)
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.verts.index_update()
        selected_edges = [edge for edge in bm.edges if edge.select]
        if not selected_edges:
            raise RoofForgeError("В Edit Mode выделите одно замкнутое кольцо рёбер карниза.")
        coordinates = {vert.index: (obj.matrix_world @ vert.co) for vert in bm.verts}
        edge_pairs = [(edge.verts[0].index, edge.verts[1].index) for edge in selected_edges]
        return _order_single_loop(coordinates, edge_pairs)

    mesh = obj.data
    if not mesh.edges:
        raise RoofForgeError("У активного Mesh нет рёбер.")
    if len(mesh.polygons) == 0:
        edge_pairs = [tuple(edge.vertices) for edge in mesh.edges]
    else:
        edge_use_count = defaultdict(int)
        for polygon in mesh.polygons:
            for edge_key in polygon.edge_keys:
                edge_use_count[tuple(sorted(edge_key))] += 1
        edge_pairs = [tuple(edge.vertices) for edge in mesh.edges if edge_use_count.get(tuple(sorted(edge.vertices)), 0) == 1]
    if not edge_pairs:
        raise RoofForgeError("Не найдено граничное кольцо. Выделите loop в Edit Mode или используйте mesh-контур без граней.")
    coordinates = {vert.index: (obj.matrix_world @ vert.co) for vert in mesh.vertices}
    return _order_single_loop(coordinates, edge_pairs)


def _prepare_local_polygon(world_points):
    xs = [point.x for point in world_points]
    ys = [point.y for point in world_points]
    zs = [point.z for point in world_points]
    center_x = sum(xs) / len(xs)
    center_y = sum(ys) / len(ys)
    base_z = sum(zs) / len(zs)
    diagonal = math.hypot(max(xs) - min(xs), max(ys) - min(ys))
    z_tolerance = max(1.0e-5, diagonal * 1.0e-5)
    if max(zs) - min(zs) > z_tolerance:
        raise RoofForgeError("Контур карниза должен лежать в горизонтальной плоскости XY. Выровняйте вершины по Z.")
    local = [(point.x - center_x, point.y - center_y) for point in world_points]
    local = _simplify_polygon(local, max(diagonal, 1.0))
    return local, (center_x, center_y, base_z)


# -----------------------------------------------------------------------------
# Mesh construction and live object rebuilding
# -----------------------------------------------------------------------------


def _extrude_mesh_global_z(vertices, faces, local_offset):
    """Give a roof surface real mesh thickness by translating it along WORLD +Z.

    ``local_offset`` is the world +Z vector transformed into the object's local
    coordinates. The original surface becomes the underside, the translated
    copy is the upper surface, and only boundary edges receive side walls.
    No Solidify modifier is involved.
    """
    if not vertices or not faces:
        return list(vertices), list(faces)
    offset = (float(local_offset[0]), float(local_offset[1]), float(local_offset[2]))
    count = len(vertices)
    bottom = [tuple(map(float, v)) for v in vertices]
    top = [(v[0] + offset[0], v[1] + offset[1], v[2] + offset[2]) for v in bottom]
    out_vertices = bottom + top

    # Reverse the original faces for the underside; translated faces retain
    # their upward-facing winding.
    out_faces = [tuple(reversed(face)) for face in faces]
    out_faces.extend(tuple(index + count for index in face) for face in faces)

    edge_uses = defaultdict(list)
    for face in faces:
        for i, a in enumerate(face):
            b = face[(i + 1) % len(face)]
            key = (a, b) if a < b else (b, a)
            edge_uses[key].append((a, b))

    for uses in edge_uses.values():
        if len(uses) != 1:
            continue
        a, b = uses[0]
        # Winding follows the top boundary so the wall normal points outward.
        out_faces.append((a, b, b + count, a + count))

    return out_vertices, out_faces


def _replace_mesh_data(obj, name, vertices, faces):
    """Replace mesh data without remeshing, dissolving, smoothing or subdividing.

    The polygons passed by the roof solver are the intended mathematical faces.
    Keeping them intact is essential: coplanar edges are still meaningful when
    they belong to the actual roof topology (ridge/valley graph).
    """
    mesh = bpy.data.meshes.new(name)
    mesh.from_pydata(vertices, [], faces)
    mesh.validate(verbose=False)
    mesh.update()
    if len(mesh.polygons):
        bm = bmesh.new()
        bm.from_mesh(mesh)
        bmesh.ops.recalc_face_normals(bm, faces=list(bm.faces))
        bm.to_mesh(mesh)
        bm.free()
        mesh.update()
    for polygon in mesh.polygons:
        polygon.use_smooth = False
    old = obj.data
    obj.data = mesh
    if old and old.users == 0:
        bpy.data.meshes.remove(old)


def _remove_helper_object(roof_obj, custom_key):
    helper_name = roof_obj.get(custom_key, "")
    helper = bpy.data.objects.get(helper_name) if helper_name else None
    if helper is not None and helper.get("roofforge_helper", False):
        helper_mesh = helper.data if helper.type == 'MESH' else None
        bpy.data.objects.remove(helper, do_unlink=True)
        if helper_mesh is not None and helper_mesh.users == 0:
            bpy.data.meshes.remove(helper_mesh)
    roof_obj[custom_key] = ""


def _ensure_helper_object(roof_obj, suffix, custom_key):
    helper_name = roof_obj.get(custom_key, "")
    helper = bpy.data.objects.get(helper_name) if helper_name else None
    if helper is None or helper.type != 'MESH':
        mesh = bpy.data.meshes.new(roof_obj.name + suffix + "_Mesh")
        helper = bpy.data.objects.new(roof_obj.name + suffix, mesh)
        collection = roof_obj.users_collection[0] if roof_obj.users_collection else bpy.context.scene.collection
        collection.objects.link(helper)
        helper.parent = roof_obj
        helper.location = (0.0, 0.0, 0.0)
        helper.rotation_euler = (0.0, 0.0, 0.0)
        helper.scale = (1.0, 1.0, 1.0)
        helper["roofforge_helper"] = True
        roof_obj[custom_key] = helper.name
    return helper


def _settings_values(settings):
    return {
        "roof_type": settings.roof_type,
        "pitch_angle": settings.pitch_angle,
        "overhang": settings.overhang,
        "eave_lift": settings.eave_lift,
        "thickness": settings.thickness,
        "make_solid": settings.make_solid,
        "shed_rise_angle": settings.shed_rise_angle,
        "show_ridges": settings.show_ridges,
        "ridge_width": settings.ridge_width,
        "ridge_extrusion": settings.ridge_extrusion,
        "ridge_end_offset": settings.ridge_end_offset,
        "show_valleys": settings.show_valleys,
        "valley_width": settings.valley_width,
        "valley_extrusion": settings.valley_extrusion,
        "valley_end_offset": settings.valley_end_offset,
        "show_standing_seams": settings.show_standing_seams,
        "standing_panel_width": settings.standing_panel_width,
        "standing_seam_height": settings.standing_seam_height,
        "standing_seam_width": settings.standing_seam_width,
        "end_offsets_migrated": True,
    }


def _update_roof_modifiers(roof_obj, settings):
    # RoofForge thickness is explicit mesh geometry; no Solidify or Bevel.
    for modifier in tuple(roof_obj.modifiers):
        if modifier.name in {"RoofForge Thickness", "RoofForge Bevel"}:
            roof_obj.modifiers.remove(modifier)


def _world_surface_from_mesh_object(roof_obj):
    """Extract evaluated upward-facing roof facets without changing the source.

    Modifiers are evaluated first, then a temporary BMesh dissolves tiny
    coplanar partitions (including triangulation) so panel lines are not
    restarted at invisible internal edges. Coordinates are transformed to
    world space so all panel dimensions remain scene-unit values.
    """
    evaluated_obj = None
    evaluated_mesh = None
    bm = bmesh.new()
    try:
        source_mesh = roof_obj.data
        try:
            depsgraph = bpy.context.evaluated_depsgraph_get()
            evaluated_obj = roof_obj.evaluated_get(depsgraph)
            evaluated_mesh = evaluated_obj.to_mesh()
            if evaluated_mesh is not None:
                source_mesh = evaluated_mesh
        except (AttributeError, RuntimeError, TypeError):
            evaluated_obj = None
            evaluated_mesh = None

        if source_mesh is None or not source_mesh.polygons:
            raise RoofForgeError("У выбранного объекта нет граней крыши.")

        bm.from_mesh(source_mesh)
        bm.normal_update()
        try:
            bmesh.ops.dissolve_limit(
                bm,
                angle_limit=math.radians(0.01),
                use_dissolve_boundaries=False,
                verts=list(bm.verts),
                edges=list(bm.edges),
            )
            bm.normal_update()
        except (TypeError, RuntimeError, AttributeError):
            # Keep the evaluated input intact if a particular build cannot
            # perform limited dissolve on the temporary BMesh.
            pass

        bm.verts.index_update()
        transform = evaluated_obj.matrix_world if evaluated_obj is not None else roof_obj.matrix_world
        world_points = [transform @ vert.co for vert in bm.verts]
        source_faces = []
        for face in bm.faces:
            if len(face.verts) < 3:
                continue
            coords = [world_points[v.index] for v in face.verts]
            nx = ny = nz = 0.0
            for i, point in enumerate(coords):
                nxt = coords[(i + 1) % len(coords)]
                nx += (point.y - nxt.y) * (point.z + nxt.z)
                ny += (point.z - nxt.z) * (point.x + nxt.x)
                nz += (point.x - nxt.x) * (point.y + nxt.y)
            length = math.sqrt(nx * nx + ny * ny + nz * nz)
            if length <= 1.0e-12:
                continue
            if nz / length > 0.05:
                source_faces.append(tuple(v.index for v in face.verts))

        if not source_faces:
            raise RoofForgeError(
                "Не найдены верхние грани крыши. Проверьте нормали и геометрию объекта."
            )

        used = sorted({index for face in source_faces for index in face})
        remap = {old: new for new, old in enumerate(used)}
        surface_vertices = [
            (float(world_points[index].x), float(world_points[index].y), float(world_points[index].z))
            for index in used
        ]
        surface_faces = [tuple(remap[index] for index in face) for face in source_faces]
        face_sources = [-1] * len(surface_faces)
        ridge_graph = extract_roof_seams(surface_vertices, surface_faces, face_sources, [])
        return surface_vertices, surface_faces, ridge_graph
    finally:
        bm.free()
        if evaluated_obj is not None and evaluated_mesh is not None:
            try:
                evaluated_obj.to_mesh_clear()
            except (AttributeError, RuntimeError, ReferenceError):
                pass


def _rebuild_standing_seams_for_mesh(roof_obj):
    """Live-rebuild standing seams on a selected/generated roof mesh object."""
    if not roof_obj or roof_obj.type != 'MESH' or roof_obj.get('roofforge_standing_updating', False):
        return
    roof_obj['roofforge_standing_updating'] = True
    try:
        settings = roof_obj.roofforge_settings
        if settings.show_standing_seams:
            standing_obj = _ensure_helper_object(
                roof_obj, "_StandingSeams", "roofforge_standing_seams_object"
            )
            surface_vertices, surface_faces, ridge_graph = _world_surface_from_mesh_object(roof_obj)
            if roof_obj.get("roofforge_generated", False):
                roof_thickness = float(settings.thickness) if settings.make_solid else 0.0
            else:
                # For an imported solid roof, this is the thickness used to
                # sink invisible rib feet inside the existing shell.
                roof_thickness = float(settings.thickness)
            sv, sf, stats = build_standing_seam_mesh(
                surface_vertices,
                surface_faces,
                ridge_graph,
                panel_width=settings.standing_panel_width,
                seam_height=settings.standing_seam_height,
                seam_base_width=settings.standing_seam_width,
                roof_thickness=roof_thickness,
                ridge_height=settings.ridge_extrusion,
            )
            inverse = roof_obj.matrix_world.inverted_safe()
            local_vertices = []
            for vertex in sv:
                point = inverse @ Vector(vertex)
                local_vertices.append((float(point.x), float(point.y), float(point.z)))
            _replace_mesh_data(standing_obj, standing_obj.name + "_Mesh", local_vertices, sf)
            roof_obj["roofforge_standing_effective_height"] = stats.get("effective_height_max", 0.0)
            roof_obj["roofforge_standing_segment_count"] = stats.get("segments", 0)
            roof_obj["roofforge_standing_stats"] = json.dumps(stats, separators=(",", ":"))
        else:
            _remove_helper_object(roof_obj, "roofforge_standing_seams_object")
            roof_obj["roofforge_standing_effective_height"] = 0.0
            roof_obj["roofforge_standing_segment_count"] = 0
        roof_obj["roofforge_standing_error"] = ""
    except Exception as exc:
        roof_obj["roofforge_standing_error"] = str(exc)
    finally:
        roof_obj["roofforge_standing_updating"] = False


def _rebuild_generated_roof(roof_obj):
    if not roof_obj or roof_obj.type != 'MESH' or not roof_obj.get('roofforge_generated', False):
        return
    if roof_obj.get('roofforge_updating', False):
        return
    roof_obj['roofforge_updating'] = True
    try:
        settings = roof_obj.roofforge_settings
        source_poly = json.loads(roof_obj.get('roofforge_outline', '[]'))
        if len(source_poly) < 3:
            raise RoofForgeError(
                "В объекте крыши отсутствует сохранённый исходный контур. Создайте крышу заново."
            )
        source_poly = [(float(p[0]), float(p[1])) for p in source_poly]
        if settings.roof_type in {'HIP', 'HIP_FREE'}:
            # Keep the eave extension and seam end clipping on the exact same
            # normalized footprint that the skeleton core uses. This snapping
            # only removes sub-0.001-degree angular noise on otherwise
            # orthogonal loops; genuinely oblique outlines remain untouched.
            source_poly, _was_orthogonalized = _orthogonalize_nearly_orthogonal_contour(
                source_poly
            )
        poly = _offset_polygon(source_poly, settings.overhang)

        # The HIP event graph is always solved from the original eave loop.
        # Overhang is then applied only to the source-edge portions of each
        # already-computed planar facet. This keeps ridge/valley nodes stable
        # while lowering the new outer eave line by tan(pitch) * overhang.
        if settings.roof_type in {'HIP', 'HIP_FREE'}:
            surface_vertices, surface_faces, face_source_ids = _create_surface_geometry(
                source_poly, settings
            )
            if settings.overhang > 1.0e-10:
                surface_vertices, surface_faces, face_source_ids = extend_roof_mesh_eaves(
                    surface_vertices, surface_faces, face_source_ids,
                    source_poly, poly, settings.overhang, math.tan(settings.pitch_angle)
                )
        else:
            # For non-HIP modes the footprint is still offset before surface
            # creation. Shift the plane intercept so the original eave loop
            # remains the seating datum. Shed roofs use their actual rise
            # direction; gables add exactly one overhang width to half-span.
            eave_lift = settings.eave_lift
            if settings.roof_type == 'GABLE' and settings.overhang > 1.0e-10:
                eave_lift -= math.tan(settings.pitch_angle) * settings.overhang
            elif settings.roof_type == 'SHED' and settings.overhang > 1.0e-10:
                direction = (math.cos(settings.shed_rise_angle),
                             math.sin(settings.shed_rise_angle))
                source_low = min(_dot(point, direction) for point in source_poly)
                expanded_low = min(_dot(point, direction) for point in poly)
                eave_lift += (expanded_low - source_low) * math.tan(settings.pitch_angle)
            surface_vertices, surface_faces, face_source_ids = _create_surface_geometry(
                poly, settings, eave_lift
            )

        # Compute all roof seams from shared face edges, not from independent
        # approximate polylines. The same graph drives both ridge and valley caps.
        world_thickness = Vector((0.0, 0.0, settings.thickness if settings.make_solid else 0.0))
        local_thickness = roof_obj.matrix_world.inverted_safe().to_3x3() @ world_thickness
        thickness_offset = (float(local_thickness.x), float(local_thickness.y), float(local_thickness.z))
        if settings.make_solid and settings.thickness > 0.0:
            mesh_vertices, mesh_faces = _extrude_mesh_global_z(
                surface_vertices, surface_faces, thickness_offset
            )
            cap_surface_vertices = [
                (v[0] + thickness_offset[0], v[1] + thickness_offset[1], v[2] + thickness_offset[2])
                for v in surface_vertices
            ]
        else:
            mesh_vertices, mesh_faces = list(surface_vertices), list(surface_faces)
            cap_surface_vertices = list(surface_vertices)

        _replace_mesh_data(roof_obj, roof_obj.name + "_Mesh", mesh_vertices, mesh_faces)
        _update_roof_modifiers(roof_obj, settings)

        seams = extract_roof_seams(
            cap_surface_vertices, surface_faces, face_source_ids,
            source_poly if settings.roof_type in {'HIP', 'HIP_FREE'} else poly
        )

        ridge_obj = _ensure_helper_object(roof_obj, "_Ridges", "roofforge_ridges_object")
        valley_obj = _ensure_helper_object(roof_obj, "_Valleys", "roofforge_valleys_object")

        if settings.show_ridges:
            ridge_world_vector = Vector((0.0, 0.0, settings.ridge_extrusion))
            ridge_local_vector = roof_obj.matrix_world.inverted_safe().to_3x3() @ ridge_world_vector
            sink_world_vector = Vector((0.0, 0.0, -0.0002))
            sink_local_vector = roof_obj.matrix_world.inverted_safe().to_3x3() @ sink_world_vector
            rv, rf = build_inset_seam_profile_mesh(
                cap_surface_vertices, surface_faces, seams, "RIDGE",
                settings.ridge_width,
                (ridge_local_vector.x, ridge_local_vector.y, ridge_local_vector.z),
                end_offset=settings.ridge_end_offset,
                seat_sink_offset=(sink_local_vector.x, sink_local_vector.y, sink_local_vector.z),
                outline=poly,
            )
        else:
            rv, rf = [], []

        if settings.show_valleys:
            valley_world_vector = Vector((0.0, 0.0, settings.valley_extrusion))
            valley_local_vector = roof_obj.matrix_world.inverted_safe().to_3x3() @ valley_world_vector
            sink_world_vector = Vector((0.0, 0.0, -0.0002))
            sink_local_vector = roof_obj.matrix_world.inverted_safe().to_3x3() @ sink_world_vector
            vv, vf = build_inset_seam_profile_mesh(
                cap_surface_vertices, surface_faces, seams, "VALLEY",
                settings.valley_width,
                (valley_local_vector.x, valley_local_vector.y, valley_local_vector.z),
                end_offset=settings.valley_end_offset,
                seat_sink_offset=(sink_local_vector.x, sink_local_vector.y, sink_local_vector.z),
                outline=poly,
            )
        else:
            vv, vf = [], []

        _replace_mesh_data(ridge_obj, ridge_obj.name + "_Mesh", rv, rf)
        _replace_mesh_data(valley_obj, valley_obj.name + "_Mesh", vv, vf)

        if settings.show_standing_seams:
            standing_obj = _ensure_helper_object(
                roof_obj, "_StandingSeams", "roofforge_standing_seams_object"
            )
            # Build the detail in world space so panel width, sink depth and
            # fold height remain real scene-unit values even after roof scale.
            world_surface = []
            for vertex in cap_surface_vertices:
                world_point = roof_obj.matrix_world @ Vector(vertex)
                world_surface.append((float(world_point.x), float(world_point.y), float(world_point.z)))
            world_ridge_graph = extract_roof_seams(
                world_surface, surface_faces, face_source_ids,
                source_poly if settings.roof_type in {'HIP', 'HIP_FREE'} else poly
            )
            seam_world_vertices, seam_faces, seam_stats = build_standing_seam_mesh(
                world_surface,
                surface_faces,
                world_ridge_graph,
                panel_width=settings.standing_panel_width,
                seam_height=settings.standing_seam_height,
                seam_base_width=settings.standing_seam_width,
                roof_thickness=(settings.thickness if settings.make_solid else 0.0),
                ridge_height=settings.ridge_extrusion,
            )
            inverse_world = roof_obj.matrix_world.inverted_safe()
            seam_vertices = []
            for vertex in seam_world_vertices:
                local_point = inverse_world @ Vector(vertex)
                seam_vertices.append((float(local_point.x), float(local_point.y), float(local_point.z)))
            _replace_mesh_data(standing_obj, standing_obj.name + "_Mesh", seam_vertices, seam_faces)
        else:
            _remove_helper_object(roof_obj, "roofforge_standing_seams_object")
            seam_stats = {"segments": 0, "effective_height_max": 0.0}
        roof_obj["roofforge_standing_effective_height"] = seam_stats.get("effective_height_max", 0.0)
        roof_obj["roofforge_standing_segment_count"] = seam_stats.get("segments", 0)
        roof_obj["roofforge_standing_stats"] = json.dumps(seam_stats, separators=(",", ":"))
        roof_obj["roofforge_standing_error"] = ""

        roof_obj["roofforge_error"] = ""
        roof_obj["roofforge_last_type"] = settings.roof_type
        roof_obj["roofforge_top_vertices"] = len(surface_vertices)
        roof_obj["roofforge_top_faces"] = len(surface_faces)
        roof_obj["roofforge_seam_edges"] = len(seams)
    except Exception as exc:
        roof_obj["roofforge_error"] = str(exc)
    finally:
        roof_obj["roofforge_updating"] = False


def _settings_update(self, context):
    owner = getattr(self, "id_data", None)
    if isinstance(owner, bpy.types.Object) and owner.get("roofforge_generated", False):
        _rebuild_generated_roof(owner)
    elif isinstance(owner, bpy.types.Object) and owner.get("roofforge_standing_source", False):
        _rebuild_standing_seams_for_mesh(owner)


def _standing_seam_settings_update(self, context):
    """Rebuild only the seam detail; do not recalculate the roof skeleton."""
    owner = getattr(self, "id_data", None)
    if isinstance(owner, bpy.types.Object) and not owner.get("roofforge_updating", False) and (
        owner.get("roofforge_generated", False)
        or owner.get("roofforge_standing_source", False)
    ):
        _rebuild_standing_seams_for_mesh(owner)


# -----------------------------------------------------------------------------
# Properties
# -----------------------------------------------------------------------------


class ROOFFORGE_PG_Settings(bpy.types.PropertyGroup):
    roof_type: EnumProperty(
        name="Тип крыши",
        description="Способ построения крыши по плану карниза",
        items=[
            ('HIP', "Вальмовая / классическая", "Прежний проверенный алгоритм; сохраняет поведение предыдущих версий"),
            ('HIP_FREE', "Вальмовая / свободные углы", "Отдельный режим для вогнутых и выпуклых контуров с косыми рёбрами и непрямыми углами"),
            ('GABLE', "Двускатная", "Два основных ската; контур должен быть параллелограммом"),
            ('SHED', "Односкатная", "Одна наклонная плоскость с заданным направлением подъёма"),
            ('FLAT', "Плоская", "Горизонтальная поверхность"),
        ],
        default='HIP', update=_settings_update,
    )
    pitch_angle: FloatProperty(
        name="Уклон ската", description="Угол кровельной поверхности к горизонтали",
        default=math.radians(30.0), min=math.radians(0.0), max=math.radians(75.0),
        subtype='ANGLE', unit='ROTATION', update=_settings_update,
    )
    pitch_default_migrated: BoolProperty(
        name="Миграция уклона выполнена", default=False, options={'HIDDEN'},
    )
    overhang: FloatProperty(
        name="Свес карниза", description="Продление скатов по их плоскостям; внешняя кромка опускается на tan(уклона) × свес, а исходный контур остаётся точкой опирания нижней поверхности",
        default=0.0, min=0.0, max=5.0, unit='LENGTH', update=_settings_update,
    )
    eave_lift: FloatProperty(
        name="Подъём от контура", description="Вертикальное смещение всей крыши вверх от уровня карниза",
        default=0.0, min=-10.0, max=10.0, unit='LENGTH', update=_settings_update,
    )
    thickness: FloatProperty(
        name="Толщина кровли", description="Реальная экструзия меша вверх по глобальной оси Z", default=0.01, min=0.001, max=2.0,
        unit='LENGTH', update=_settings_update,
    )
    make_solid: BoolProperty(
        name="Экструдировать вверх по Z", description="Создать нижнюю и верхнюю поверхности и боковые стенки геометрией меша", default=True, update=_settings_update,
    )
    shed_rise_angle: FloatProperty(
        name="Направление подъёма", description="Азимут подъёма односкатной крыши относительно мировой оси X",
        default=math.radians(90.0), min=math.radians(-360.0), max=math.radians(360.0),
        subtype='ANGLE', unit='ROTATION', update=_settings_update,
    )
    show_ridges: BoolProperty(
        name="Создать отдельный объект коньков", default=True, update=_settings_update,
    )
    ridge_width: FloatProperty(
        name="Ширина конька", default=0.18, min=0.01, max=2.0, unit='LENGTH', update=_settings_update,
    )
    ridge_extrusion: FloatProperty(
        name="Экструзия конька вверх", description="Высота профиля над поверхностью крыши",
        default=0.01, min=0.001, max=1.0, unit='LENGTH', update=_settings_update,
    )
    ridge_end_offset: FloatProperty(
        name="Смещение концов конька",
        description="Положительное значение — вылет за карниз, отрицательное — отступ внутрь",
        default=0.0, min=-3.0, max=3.0, unit='LENGTH', update=_settings_update,
    )
    # Hidden legacy values remain available for migration from 2.5.3 and older.
    ridge_end_extension: FloatProperty(
        name="Legacy: вылет конца конька", description="Совместимость со старыми .blend-файлами",
        default=0.10, min=0.0, max=3.0, unit='LENGTH', options={'HIDDEN'},
    )
    ridge_end_setback: FloatProperty(
        name="Legacy: отступ конца конька", default=0.0, min=0.0, max=3.0,
        unit='LENGTH', options={'HIDDEN'},
    )
    ridge_end_overhang: FloatProperty(
        name="Legacy: вылет конца конька", default=0.0, min=0.0, max=3.0,
        unit='LENGTH', options={'HIDDEN'},
    )
    show_valleys: BoolProperty(
        name="Создать отдельный объект ендов", default=True, update=_settings_update,
    )
    valley_width: FloatProperty(
        name="Ширина ендовы", default=0.24, min=0.01, max=2.0, unit='LENGTH', update=_settings_update,
    )
    valley_extrusion: FloatProperty(
        name="Экструзия ендовы вверх", description="Высота отдельного профиля ендовы над линией пересечения скатов",
        default=0.01, min=0.001, max=1.0, unit='LENGTH', update=_settings_update,
    )
    valley_end_offset: FloatProperty(
        name="Смещение концов ендовы",
        description="Положительное значение — вылет за карниз, отрицательное — отступ внутрь",
        default=0.0, min=-3.0, max=3.0, unit='LENGTH', update=_settings_update,
    )
    # Hidden legacy values remain available for migration from 2.5.3 and older.
    valley_end_extension: FloatProperty(
        name="Legacy: вылет конца ендовы", description="Совместимость со старыми .blend-файлами",
        default=0.10, min=0.0, max=3.0, unit='LENGTH', options={'HIDDEN'},
    )
    valley_end_setback: FloatProperty(
        name="Legacy: отступ конца ендовы", default=0.0, min=0.0, max=3.0,
        unit='LENGTH', options={'HIDDEN'},
    )
    valley_end_overhang: FloatProperty(
        name="Legacy: вылет конца ендовы", default=0.0, min=0.0, max=3.0,
        unit='LENGTH', options={'HIDDEN'},
    )
    show_standing_seams: BoolProperty(
        name="Создать фальцевую раскладку",
        description="Построить лёгкие продольные рёбра фальцев по верхним граням скатов",
        default=False, update=_standing_seam_settings_update,
    )
    standing_panel_width: FloatProperty(
        name="Ширина панели",
        description="Модуль фальцев, измеряемый по плоскости каждого ската; крайние панели автоматически балансируются",
        default=0.60, min=0.20, max=2.0, unit='LENGTH', update=_standing_seam_settings_update,
    )
    standing_seam_height: FloatProperty(
        name="Высота фальца",
        description="Высота над скатом; автоматически ограничивается 90% вертикальной экструзии конька",
        default=0.03, min=0.001, max=0.5, unit='LENGTH', update=_standing_seam_settings_update,
    )
    standing_seam_width: FloatProperty(
        name="Ширина основания фальца",
        description="Ширина узкой folded-полосы на поверхности ската",
        default=0.014, min=0.004, max=0.08, unit='LENGTH', update=_standing_seam_settings_update,
    )
    end_offsets_migrated: BoolProperty(
        name="Legacy endpoint settings migrated", default=False, options={'HIDDEN'},
    )


# -----------------------------------------------------------------------------
# Operators and UI
# -----------------------------------------------------------------------------


class ROOFFORGE_OT_Create(bpy.types.Operator):
    bl_idname = "roofforge.create_roof"
    bl_label = "Создать крышу"
    bl_description = "Создать параметрическую крышу; её ползунки будут пересобирать геометрию в реальном времени"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.object is not None and context.object.type == 'MESH'

    def execute(self, context):
        source_obj = context.object
        scene_settings = context.scene.roofforge_settings
        was_edit_mode = bool(source_obj and source_obj.mode == 'EDIT')
        roof_obj = None
        try:
            world_points = _extract_loop_from_object(source_obj)
            polygon, origin = _prepare_local_polygon(world_points)
            # Validate the selected outline before creating a scene object.
            if was_edit_mode:
                bpy.ops.object.mode_set(mode='OBJECT')

            mesh = bpy.data.meshes.new(source_obj.name + "_Roof_Mesh")
            roof_obj = bpy.data.objects.new(source_obj.name + "_Roof", mesh)
            collection = context.collection or context.scene.collection
            collection.objects.link(roof_obj)
            roof_obj.location = origin
            roof_obj["roofforge_source"] = source_obj.name
            roof_obj["roofforge_outline"] = json.dumps(polygon, separators=(",", ":"))
            roof_obj["roofforge_ridges_object"] = ""
            roof_obj["roofforge_valleys_object"] = ""
            roof_obj["roofforge_standing_seams_object"] = ""

            target_settings = roof_obj.roofforge_settings
            for prop_name in _settings_values(scene_settings):
                setattr(target_settings, prop_name, getattr(scene_settings, prop_name))
            # Enable callbacks only after all starting values have been copied.
            roof_obj["roofforge_generated"] = True

            _rebuild_generated_roof(roof_obj)
            error = roof_obj.get("roofforge_error", "")
            if error:
                raise RoofForgeError(error)

            bpy.ops.object.select_all(action='DESELECT')
            roof_obj.select_set(True)
            context.view_layer.objects.active = roof_obj
            self.report({'INFO'}, "Параметрическая крыша создана. Настройки доступны в RoofForge.")
            return {'FINISHED'}
        except RoofForgeError as exc:
            if roof_obj is not None:
                for child in list(roof_obj.children):
                    bpy.data.objects.remove(child, do_unlink=True)
                bpy.data.objects.remove(roof_obj, do_unlink=True)
            if was_edit_mode and source_obj and source_obj.mode != 'EDIT':
                try:
                    bpy.ops.object.select_all(action='DESELECT')
                    source_obj.select_set(True)
                    context.view_layer.objects.active = source_obj
                    bpy.ops.object.mode_set(mode='EDIT')
                except Exception:
                    pass
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        except Exception as exc:
            if roof_obj is not None:
                for child in list(roof_obj.children):
                    bpy.data.objects.remove(child, do_unlink=True)
                bpy.data.objects.remove(roof_obj, do_unlink=True)
            if was_edit_mode and source_obj and source_obj.mode != 'EDIT':
                try:
                    bpy.ops.object.select_all(action='DESELECT')
                    source_obj.select_set(True)
                    context.view_layer.objects.active = source_obj
                    bpy.ops.object.mode_set(mode='EDIT')
                except Exception:
                    pass
            self.report({'ERROR'}, "RoofForge: ошибка: " + str(exc))
            return {'CANCELLED'}



class ROOFFORGE_OT_GenerateStandingSeams(bpy.types.Operator):
    bl_idname = "roofforge.generate_standing_seams"
    bl_label = "Создать фальцы на выбранной крыше"
    bl_description = "Анализировать верхние грани выбранного меша и создать фальцы отдельным лёгким объектом"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.object
        return (
            obj is not None and obj.type == 'MESH'
            and obj.mode == 'OBJECT'
            and not obj.get("roofforge_helper", False)
        )

    def execute(self, context):
        obj = context.object
        try:
            scene_settings = context.scene.roofforge_settings
            target = obj.roofforge_settings
            obj["roofforge_standing_updating"] = True
            try:
                for name in ("show_standing_seams", "standing_panel_width", "standing_seam_height", "standing_seam_width", "thickness", "make_solid", "ridge_extrusion"):
                    setattr(target, name, getattr(scene_settings, name))
                target.show_standing_seams = True
                obj["roofforge_standing_source"] = True
            finally:
                obj["roofforge_standing_updating"] = False
            _rebuild_standing_seams_for_mesh(obj)
            error = obj.get("roofforge_standing_error", "")
            if error:
                self.report({'ERROR'}, error)
                return {'CANCELLED'}
            count = int(obj.get("roofforge_standing_segment_count", 0))
            self.report({'INFO'}, f"Создано фальцевых рёбер: {count}.")
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'}, "RoofForge: " + str(exc))
            return {'CANCELLED'}


class ROOFFORGE_OT_RebuildStandingSeams(bpy.types.Operator):
    bl_idname = "roofforge.rebuild_standing_seams"
    bl_label = "Обновить фальцы"
    bl_description = "Повторно проанализировать верхние грани исходного меша"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.object
        if obj is not None and obj.get("roofforge_helper", False) and obj.parent is not None:
            obj = obj.parent
        return obj is not None and obj.type == 'MESH' and obj.get("roofforge_standing_source", False)

    def execute(self, context):
        obj = context.object
        if obj.get("roofforge_helper", False) and obj.parent is not None:
            obj = obj.parent
        _rebuild_standing_seams_for_mesh(obj)
        error = obj.get("roofforge_standing_error", "")
        if error:
            self.report({'ERROR'}, error)
            return {'CANCELLED'}
        self.report({'INFO'}, "Фальцы обновлены.")
        return {'FINISHED'}


class ROOFFORGE_OT_Rebuild(bpy.types.Operator):
    bl_idname = "roofforge.rebuild_roof"
    bl_label = "Пересобрать крышу"
    bl_description = "Перестроить активную параметрическую крышу"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.object
        if obj is not None and obj.get("roofforge_helper", False) and obj.parent is not None:
            obj = obj.parent
        return obj is not None and obj.type == 'MESH' and obj.get("roofforge_generated", False)

    def execute(self, context):
        obj = context.object
        if obj.get("roofforge_helper", False) and obj.parent is not None:
            obj = obj.parent
        _rebuild_generated_roof(obj)
        error = obj.get("roofforge_error", "")
        if error:
            self.report({'ERROR'}, error)
            return {'CANCELLED'}
        self.report({'INFO'}, "Крыша обновлена.")
        return {'FINISHED'}


class ROOFFORGE_PT_Panel(bpy.types.Panel):
    bl_label = "RoofForge"
    bl_idname = "ROOFFORGE_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "RoofForge"

    def draw(self, context):
        layout = self.layout
        active = context.object
        roof_obj = active
        if active and active.get("roofforge_helper", False) and active.parent is not None:
            roof_obj = active.parent
        is_generated = bool(roof_obj and roof_obj.type == 'MESH' and roof_obj.get("roofforge_generated", False))
        is_standing_source = bool(roof_obj and roof_obj.type == 'MESH' and roof_obj.get("roofforge_standing_source", False))
        settings = roof_obj.roofforge_settings if (is_generated or is_standing_source) else context.scene.roofforge_settings

        if is_generated:
            layout.label(text="Параметрическая крыша", icon='HOME')
            layout.label(text=roof_obj.name, icon='MESH_DATA')
            err = roof_obj.get("roofforge_error", "")
            if err:
                box = layout.box()
                box.alert = True
                box.label(text="Ошибка пересборки", icon='ERROR')
                box.label(text=err[:120])
            layout.label(text="Плоские скаты, без сеточного подразделения.", icon='TIME')
            if roof_obj.get("roofforge_top_vertices", 0):
                layout.label(text=f"Скаты: {roof_obj.get('roofforge_top_vertices', 0)} вершин / {roof_obj.get('roofforge_top_faces', 0)} граней")
        elif is_standing_source:
            layout.label(text="Фальцы на существующем меше", icon='MESH_DATA')
            layout.label(text=roof_obj.name)
            standing_error = roof_obj.get("roofforge_standing_error", "")
            if standing_error:
                box = layout.box()
                box.alert = True
                box.label(text=standing_error[:140], icon='ERROR')
        else:
            layout.label(text="Источник: один замкнутый контур карниза", icon='MESH_CIRCLE')
            layout.label(text="Edit Mode: выделите рёбра одного edge loop.")
            layout.label(text="Object Mode: используйте отдельный граничный loop.")

        if not is_standing_source:
            layout.separator()
            layout.label(text="Геометрия крыши", icon='MOD_BUILD')
            layout.prop(settings, "roof_type")
            if settings.roof_type == 'HIP_FREE':
                layout.label(text="Wavefront для косых и непрямых углов", icon='INFO')
            layout.prop(settings, "pitch_angle")
            layout.prop(settings, "overhang")
            layout.prop(settings, "eave_lift")
            if settings.roof_type == 'SHED':
                layout.prop(settings, "shed_rise_angle")
            elif settings.roof_type == 'GABLE':
                layout.label(text="Только четырёхугольник-параллелограмм", icon='INFO')

            layout.separator()
            layout.label(text="Толщина кровли", icon='OUTLINER_OB_MESH')
            layout.prop(settings, "make_solid")
            if settings.make_solid:
                layout.prop(settings, "thickness")
                layout.label(text="Реальная геометрия: экструзия +Z", icon='INFO')

            layout.separator()
            layout.label(text="Коньки — цельные inset-полосы по скатам", icon='MESH_CUBE')
            layout.prop(settings, "show_ridges")
            if settings.show_ridges:
                box = layout.box()
                box.prop(settings, "ridge_width")
                box.prop(settings, "ridge_extrusion")
                box.prop(settings, "ridge_end_offset")

            layout.separator()
            layout.label(text="Ендовы — цельные inset-полосы по скатам", icon='MOD_BOOLEAN')
            layout.prop(settings, "show_valleys")
            if settings.show_valleys:
                box = layout.box()
                box.prop(settings, "valley_width")
                box.prop(settings, "valley_extrusion")
                box.prop(settings, "valley_end_offset")

        layout.separator()
        seam_box = layout.box()
        seam_box.label(text="Фальцевая кровля", icon='MOD_ARRAY')
        if is_generated or is_standing_source:
            seam_box.prop(settings, "show_standing_seams")
            if settings.show_standing_seams:
                seam_box.prop(settings, "standing_panel_width")
                seam_box.prop(settings, "standing_seam_height")
                seam_box.prop(settings, "standing_seam_width")
                if is_standing_source:
                    seam_box.prop(settings, "thickness", text="Толщина для заглубления")
                    seam_box.prop(settings, "ridge_extrusion", text="Высота ограничивающего конька")
                effective = float(roof_obj.get("roofforge_standing_effective_height", 0.0))
                seam_box.label(text=f"Фактическая высота: {effective:.4f} м")
                seam_box.label(text="Высота по нормали; лимит 90% от конька.", icon='INFO')
                seam_box.label(text="Нижняя грань удалена; ножка заглублена на 1/2 толщины.", icon='INFO')
                seam_box.label(text="Торцы у коньков заглублены и открыты.", icon='INFO')
                standing_error = roof_obj.get("roofforge_standing_error", "")
                if standing_error:
                    seam_box.alert = True
                    seam_box.label(text=standing_error[:100], icon='ERROR')
        else:
            scene_settings = context.scene.roofforge_settings
            seam_box.prop(scene_settings, "show_standing_seams")
            if scene_settings.show_standing_seams:
                seam_box.prop(scene_settings, "standing_panel_width")
                seam_box.prop(scene_settings, "standing_seam_height")
                seam_box.prop(scene_settings, "standing_seam_width")
            seam_box.prop(scene_settings, "ridge_extrusion", text="Высота ограничивающего конька")
            seam_box.operator("roofforge.generate_standing_seams", icon='MOD_ARRAY')
            seam_box.label(text="Работает по верхним граням выбранного меша.", icon='INFO')
            seam_box.label(text="Высота ограничивается до 90% высоты конька.", icon='INFO')

        layout.separator()
        if is_generated:
            layout.operator("roofforge.rebuild_roof", icon='FILE_REFRESH')
            layout.label(text="Исходный контур сохранён внутри объекта крыши.", icon='INFO')
        elif is_standing_source:
            layout.operator("roofforge.rebuild_standing_seams", icon='FILE_REFRESH')
        else:
            layout.operator("roofforge.create_roof", icon='HOME')
        layout.label(text="Размеры задаются в единицах Blender.", icon='INFO')


CLASSES = (
    ROOFFORGE_PG_Settings,
    ROOFFORGE_OT_Create,
    ROOFFORGE_OT_GenerateStandingSeams,
    ROOFFORGE_OT_RebuildStandingSeams,
    ROOFFORGE_OT_Rebuild,
    ROOFFORGE_PT_Panel,
)


def _migrate_legacy_thickness():
    """Migrate the old 0.18 m default after Blender has finished registration.

    Blender may expose bpy.data as _RestrictData while an extension's register()
    function is running. This callback is deliberately deferred through the
    application timer, where normal data access is available.
    """
    try:
        scenes = tuple(bpy.data.scenes)
        objects = tuple(bpy.data.objects)
    except (AttributeError, ReferenceError, RuntimeError):
        # Keep retrying if Blender is still in its restricted startup phase.
        return 0.5

    for scene in scenes:
        settings = getattr(scene, "roofforge_settings", None)
        if settings is None:
            continue
        if abs(settings.thickness - 0.18) < 1.0e-7:
            settings.thickness = 0.01
        _migrate_endpoint_offsets(settings)
        _migrate_pitch_default(settings)

    for obj in objects:
        if obj.get("roofforge_generated", False):
            settings = getattr(obj, "roofforge_settings", None)
            if settings is not None:
                if abs(settings.thickness - 0.18) < 1.0e-7:
                    settings.thickness = 0.01
                _migrate_endpoint_offsets(settings)
                _migrate_pitch_default(settings)

    return None


def _migrate_endpoint_offsets(settings):
    """Convert old overhang/setback pairs into one signed endpoint offset."""
    if getattr(settings, "end_offsets_migrated", False):
        return
    settings.ridge_end_offset = (
        float(settings.ridge_end_overhang) - float(settings.ridge_end_setback)
    )
    settings.valley_end_offset = (
        float(settings.valley_end_overhang) - float(settings.valley_end_setback)
    )
    settings.end_offsets_migrated = True


def _migrate_pitch_default(settings):
    """Convert the accidental saved 0-degree default to the intended 30 degrees once.

    Explicit non-zero user values are retained. The hidden marker prevents a
    user from being forced back to 30 degrees after intentionally editing the
    slope later in the project.
    """
    if getattr(settings, "pitch_default_migrated", False):
        return
    try:
        current_pitch = float(settings.pitch_angle)
    except (AttributeError, TypeError, ValueError):
        current_pitch = math.radians(30.0)
    if abs(current_pitch) <= 1.0e-8:
        settings.pitch_angle = math.radians(30.0)
    settings.pitch_default_migrated = True


def _schedule_legacy_migration():
    """Schedule migration without touching bpy.data during register()."""
    try:
        if not bpy.app.timers.is_registered(_migrate_legacy_thickness):
            bpy.app.timers.register(_migrate_legacy_thickness, first_interval=0.5)
    except (AttributeError, ReferenceError, RuntimeError):
        # Registration itself must remain successful even in restricted context.
        pass


def _roofforge_load_post(_unused):
    # Re-run after a .blend is opened: the add-on can be enabled before the
    # user's project data is loaded, so an initial registration timer is not
    # sufficient for every startup order.
    _schedule_legacy_migration()


# Mark the handler persistent so opening another .blend keeps migration support.
_roofforge_load_post = bpy.app.handlers.persistent(_roofforge_load_post)


def register():
    # Do not enumerate bpy.data here. Blender can pass _RestrictData while
    # importing/registering extensions, which has no .scenes/.objects access.
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.roofforge_settings = PointerProperty(type=ROOFFORGE_PG_Settings)
    bpy.types.Object.roofforge_settings = PointerProperty(type=ROOFFORGE_PG_Settings)

    if _roofforge_load_post not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_roofforge_load_post)
    _schedule_legacy_migration()


def unregister():
    if _roofforge_load_post in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_roofforge_load_post)

    try:
        if bpy.app.timers.is_registered(_migrate_legacy_thickness):
            bpy.app.timers.unregister(_migrate_legacy_thickness)
    except (AttributeError, ReferenceError, RuntimeError):
        pass

    if hasattr(bpy.types.Scene, "roofforge_settings"):
        del bpy.types.Scene.roofforge_settings
    if hasattr(bpy.types.Object, "roofforge_settings"):
        del bpy.types.Object.roofforge_settings
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
